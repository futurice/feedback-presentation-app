seed-element
================

See the [component page](http://polymerlabs.github.io/seed-element) for more information.

## Getting Started

We've put together a [guide to seed-element](http://www.polymer-project.org/docs/start/reusableelements.html) to help get you rolling.
